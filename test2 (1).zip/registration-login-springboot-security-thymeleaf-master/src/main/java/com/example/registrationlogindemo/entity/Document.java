package com.example.registrationlogindemo.entity;

public class Document {
	private int id;
	private int did;
	private String dname;
}
